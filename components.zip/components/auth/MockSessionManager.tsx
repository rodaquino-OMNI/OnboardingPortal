'use client';

import React, { useState, useEffect } from 'react';
import { logger } from '@/lib/logger';

interface MockSession {
  id: string;
  device: string;
  ip: string;
  location: string;
  last_active: string;
  current: boolean;
  suspicious?: boolean;
}

interface MockSessionManagerProps {
  onSessionRevoked?: () => void;
}

/**
 * Mock Session Manager for Development Auth Bypass
 * 
 * This component provides a mock session management interface
 * when authentication bypass is enabled in development mode.
 * It maintains the same interface as the real SessionManager
 * but provides mock data and WebSocket connections.
 */
export default function MockSessionManager({ onSessionRevoked }: MockSessionManagerProps) {
  const [sessions, setSessions] = useState<MockSession[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState('');
  const [wsConnected, setWsConnected] = useState(false);

  // Mock sessions data
  const MOCK_SESSIONS: MockSession[] = [
    {
      id: 'mock-session-1',
      device: 'Chrome on macOS (Current - Dev Mode)',
      ip: '127.0.0.1',
      location: 'localhost (Development)',
      last_active: new Date().toISOString(),
      current: true
    },
    {
      id: 'mock-session-2',
      device: 'Firefox on macOS (Mock)',
      ip: '192.168.1.100',
      location: 'São Paulo, BR (Mock)',
      last_active: new Date(Date.now() - 300000).toISOString(), // 5 minutes ago
      current: false
    }
  ];

  useEffect(() => {
    // Simulate initial loading
    const loadTimer = setTimeout(() => {
      setSessions(MOCK_SESSIONS);
      setIsLoading(false);
      logger.debug('[MockSessionManager] Mock sessions loaded');
    }, 1000);

    // Simulate WebSocket connection in development
    const wsTimer = setTimeout(() => {
      setWsConnected(true);
      logger.debug('[MockSessionManager] Mock WebSocket connected');
    }, 1500);

    // Simulate periodic session updates
    const updateInterval = setInterval(() => {
      setSessions(prevSessions => 
        prevSessions.map(session => ({
          ...session,
          last_active: session.current ? new Date().toISOString() : session.last_active
        }))
      );
    }, 30000); // Update every 30 seconds

    return () => {
      clearTimeout(loadTimer);
      clearTimeout(wsTimer);
      clearInterval(updateInterval);
    };
  }, []);

  const handleRevokeSession = async (sessionId: string) => {
    logger.info('[MockSessionManager] Mock session revoked', { sessionId });
    
    // Simulate API delay
    await new Promise(resolve => setTimeout(resolve, 500));
    
    if (sessionId === 'mock-session-1') {
      setError('Cannot revoke current session in dev mode');
      setTimeout(() => setError(''), 3000);
      return;
    }
    
    setSessions(prevSessions => prevSessions.filter(s => s.id !== sessionId));
    onSessionRevoked?.();
  };

  if (isLoading) {
    return (
      <div className="max-w-2xl mx-auto p-6">
        <div className="animate-pulse">
          <div className="h-8 bg-gray-200 rounded w-1/3 mb-4"></div>
          <div className="space-y-3">
            <div className="h-20 bg-gray-200 rounded"></div>
            <div className="h-20 bg-gray-200 rounded"></div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="flex items-center justify-between mb-6">
        <h2 className="text-2xl font-bold">Active Sessions</h2>
        <span className="px-3 py-1 bg-orange-100 text-orange-700 text-sm rounded-full font-semibold">
          DEV MODE
        </span>
      </div>

      {/* Development Notice */}
      <div role="alert" className="mb-6 p-4 bg-blue-50 border border-blue-200 rounded">
        <p className="text-blue-700 font-semibold">
          🔧 Development Auth Bypass Active
        </p>
        <p className="text-sm text-blue-600 mt-1">
          This is a mock session manager for development. Real sessions are managed server-side.
        </p>
      </div>

      {error && (
        <div className="mb-4 p-3 bg-red-50 border border-red-200 rounded text-red-600 text-sm">
          {error}
        </div>
      )}

      <div className="space-y-4">
        {sessions.map(session => (
          <div
            key={session.id}
            data-testid={`session-${session.id}`}
            className={`p-4 border rounded ${
              session.current 
                ? 'border-blue-300 bg-blue-50' 
                : 'border-gray-200'
            }`}
          >
            <div className="flex justify-between items-start">
              <div>
                <p className="font-semibold">{session.device}</p>
                <p className="text-sm text-gray-600">IP: {session.ip}</p>
                <p className="text-sm text-gray-600">Location: {session.location}</p>
                <p className="text-sm text-gray-500">
                  Last active: {new Date(session.last_active).toLocaleString()}
                </p>
                {session.current && (
                  <p className="text-sm text-green-600 font-semibold mt-1">
                    ✓ Current session (Development)
                  </p>
                )}
              </div>
              {!session.current && (
                <button
                  onClick={() => handleRevokeSession(session.id)}
                  className="px-3 py-1 bg-gray-600 text-white rounded text-sm hover:bg-gray-700 transition-colors"
                >
                  Revoke (Mock)
                </button>
              )}
            </div>
          </div>
        ))}
      </div>

      {/* Mock WebSocket Status */}
      <div className="mt-6 text-sm text-gray-600 border-t pt-4">
        <div className="flex items-center justify-between">
          <p>Mock session management active</p>
          <div
            data-testid="connection-status"
            className={`flex items-center space-x-2 ${
              wsConnected ? 'text-green-600' : 'text-orange-600'
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${
              wsConnected ? 'bg-green-500' : 'bg-orange-500'
            }`} />
            <span>{wsConnected ? 'Mock WS Connected' : 'Connecting...'}</span>
          </div>
        </div>
        <p className="text-xs text-gray-500 mt-2">
          Environment: {process.env.NODE_ENV} | 
          Auth Bypass: {process.env.NEXT_PUBLIC_BYPASS_AUTH === 'true' ? 'Enabled' : 'Disabled'}
        </p>
      </div>
    </div>
  );
}

/**
 * Hook to determine which session manager to use
 */
export function useSessionManager() {
  const isAuthBypassEnabled = process.env.NEXT_PUBLIC_BYPASS_AUTH === 'true' && 
                              process.env.NODE_ENV === 'development';

  return {
    SessionManagerComponent: isAuthBypassEnabled ? MockSessionManager : null,
    isMockMode: isAuthBypassEnabled
  };
}