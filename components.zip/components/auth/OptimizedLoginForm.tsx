'use client';

import React, { useState, useCallback, useMemo } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { User, Lock, AlertCircle } from 'lucide-react';
import Link from 'next/link';
import { useRouter } from 'next/navigation';
import dynamic from 'next/dynamic';

import { loginSchema, type LoginData } from '@/lib/schemas/auth';
import { useAuth } from '@/hooks/useAuth';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

// Lazy load heavy components for better initial bundle size
const SocialLoginButton = dynamic(() => import('./SocialLoginButton'), {
  loading: () => <div className="h-12 bg-gray-100 animate-pulse rounded"></div>,
  ssr: false
});

// Memoized success animation component
const SuccessAnimation = React.memo(({ show }: { show: boolean }) => {
  if (!show) return null;
  
  return (
    <div className="fixed inset-0 flex items-center justify-center bg-black/50 z-50">
      <div className="card-modern p-8 shadow-2xl animate-bounce-in">
        <div className="text-center">
          <div className="w-20 h-20 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <svg
              className="w-10 h-10 text-green-600"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M5 13l4 4L19 7"
              />
            </svg>
          </div>
          <h3 className="text-xl font-semibold text-gray-900 mb-2">Login realizado!</h3>
          <p className="text-gray-600">Redirecionando...</p>
        </div>
      </div>
    </div>
  );
});

SuccessAnimation.displayName = 'SuccessAnimation';

// Main optimized login form component
const OptimizedLoginForm = React.memo(() => {
  const router = useRouter();
  const { error: authError } = useAuth();
  const { login, socialLogin, clearError } = useAuth();
  
  const [showSuccess, setShowSuccess] = useState(false);
  const [socialLoading, setSocialLoading] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    formState: { errors, isSubmitting },
  } = useForm<LoginData>({
    resolver: zodResolver(loginSchema),
  });

  // Memoized form submission handler
  const onSubmit = useCallback(async (data: LoginData) => {
    try {
      clearError();
      
      const result = await login(data);
      
      if (result.success) {
        setShowSuccess(true);
        setTimeout(() => {
          router.push('/home');
        }, 1500);
        return;
      }
      
    } catch (error) {
      console.error('Login error:', error);
    }
  }, [login, clearError, router]);

  // Memoized social login handler
  const handleSocialLogin = useCallback(async (provider: 'google' | 'facebook' | 'instagram') => {
    try {
      clearError();
      setSocialLoading(provider);
      await socialLogin(provider);
    } catch (error) {
      console.error('Social login error:', error);
    } finally {
      setSocialLoading(null);
    }
  }, [socialLogin, clearError]);

  // Memoized social login buttons
  const socialLoginButtons = useMemo(() => (
    <div className="space-y-3">
      <SocialLoginButton
        provider="google"
        onClick={() => handleSocialLogin('google')}
        isLoading={socialLoading === 'google'}
      />
      <SocialLoginButton
        provider="facebook"
        onClick={() => handleSocialLogin('facebook')}
        isLoading={socialLoading === 'facebook'}
      />
      <SocialLoginButton
        provider="instagram"
        onClick={() => handleSocialLogin('instagram')}
        isLoading={socialLoading === 'instagram'}
      />
    </div>
  ), [handleSocialLogin, socialLoading]);

  return (
    <div className="w-full max-w-md">
      <div className="card-modern p-8 animate-fade-in">
        <div className="text-center mb-8">
          <h1 className="text-3xl font-bold tracking-tight bg-gradient-to-r from-gray-900 to-gray-700 bg-clip-text text-transparent mb-2">
            Bem-vindo de volta!
          </h1>
          <p className="text-gray-600">Entre com suas credenciais para acessar sua conta</p>
        </div>

        <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
          <div>
            <label htmlFor="login" className="block text-sm font-medium text-gray-700 mb-2">
              E-mail
            </label>
            <Input
              id="login"
              type="text"
              placeholder="000.000.000-00 ou seu@email.com"
              icon={User}
              error={errors.login?.message}
              {...register('login')}
            />
          </div>

          <div>
            <label htmlFor="password" className="block text-sm font-medium text-gray-700 mb-2">
              Senha
            </label>
            <Input
              id="password"
              type="password"
              placeholder="••••••••"
              icon={Lock}
              error={errors.password?.message}
              {...register('password')}
            />
          </div>

          {authError && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3 flex items-start gap-2 animate-fade-in">
              <AlertCircle className="h-5 w-5 text-red-600 mt-0.5" />
              <p className="text-sm text-red-600 font-medium">{authError}</p>
            </div>
          )}

          <div className="flex items-center justify-between">
            <Link
              href="/forgot-password"
              className="text-sm text-blue-600 hover:text-blue-700 transition-colors"
            >
              Esqueceu sua senha?
            </Link>
          </div>

          <Button
            type="submit"
            fullWidth
            isLoading={isSubmitting}
            className="relative"
          >
            Entrar
          </Button>
        </form>

        {/* Social Login Divider */}
        <div className="my-6">
          <div className="relative">
            <div className="absolute inset-0 flex items-center">
              <div className="w-full border-t border-gray-300"></div>
            </div>
            <div className="relative flex justify-center text-sm">
              <span className="px-2 bg-white text-gray-500">ou continue com</span>
            </div>
          </div>
        </div>

        {/* Optimized Social Login Buttons */}
        {socialLoginButtons}

        <div className="text-center mt-6">
          <p className="text-sm text-gray-600">
            Não tem uma conta?{' '}
            <Link
              href="/register"
              className="text-blue-600 hover:text-blue-700 font-medium transition-colors"
            >
              Cadastre-se
            </Link>
          </p>
        </div>
      </div>

      {/* Optimized Success Animation */}
      <SuccessAnimation show={showSuccess} />
    </div>
  );
});

OptimizedLoginForm.displayName = 'OptimizedLoginForm';

export default OptimizedLoginForm;