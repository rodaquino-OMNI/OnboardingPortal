'use client';

// Re-export the new enhanced dashboard component
export { DashboardOverview as AdminDashboard } from './dashboard/DashboardOverview';