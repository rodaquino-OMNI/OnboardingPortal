'use client';

import { RoleManagement } from '@/components/admin/RoleManagement';

export default function RolesPage() {
  return <RoleManagement />;
}