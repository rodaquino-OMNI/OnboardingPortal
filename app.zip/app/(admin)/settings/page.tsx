'use client';

import { SystemSettings } from '@/components/admin/SystemSettings';

export default function SettingsPage() {
  return <SystemSettings />;
}