'use client';

import { SecurityAudit } from '@/components/admin/SecurityAudit';

export default function SecurityPage() {
  return <SecurityAudit />;
}